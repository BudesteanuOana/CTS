public class Director {
    CarBuider builder;

    Director(CarBuider builder) {
        this.builder = builder;
    }

    public void buildCar() {
        builder.buildModel();
        builder.buildNumarLocuri();
        builder.buildPret();
        builder.buildTrapa();
        if(builder instanceof ElectriCarBuilder) {
            ((ElectriCarBuilder) builder).buildBatteryLevel();
        } else {
            ((BasicCarBuilder)builder).buildCapacitate();
        }
    }

    public Car getCar() {
        return builder.getCar();
    }
}
