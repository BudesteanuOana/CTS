public class ElectriCarBuilder implements CarBuider {
    public Car car;

    public ElectriCarBuilder() {
        this.car = new ElectricCar();
    }

    public void buildBatteryLevel() {
        ((ElectricCar)car).setBatteryLevel(100);
    }
    @Override
    public void buildModel() {
        this.car.setModel("Pulalela");
    }

    @Override
    public void buildNumarLocuri() {
        this.car.setNumarLocuri(5);
    }

    @Override
    public void buildPret() {
        this.car.setPret(4.3);
    }

    @Override
    public void buildTrapa() {
        this.car.hasTrapa(true);
    }

    @Override
    public Car getCar() {
        return this.car;
    }
}
