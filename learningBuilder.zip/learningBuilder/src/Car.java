public interface Car {
    public void setModel(String model);
    public void setNumarLocuri(int numarLocuri);
    public void setPret(double pret);
    public void hasTrapa(boolean trapa);
    public String showDetails();
}
