public class Main {
    public static void main(String[] args) {
        CarBuider builder = new ElectriCarBuilder();
        Director director = new Director(builder);
        director.buildCar();
        Car masina = director.getCar();
        System.out.println(masina.showDetails());
    }
}