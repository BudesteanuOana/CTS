public class BasicCar implements Car {

    int numarLocuri;
    String model;
    double pret;
    boolean trapa;

    public BasicCar(int numarLocuri, String model, double pret, boolean trapa, int capacitate) {
        this.numarLocuri = numarLocuri;
        this.model = model;
        this.pret = pret;
        this.trapa = trapa;
        this.capacitate = capacitate;
    }

    public BasicCar() {
        this.numarLocuri = 0;
        this.model = "";
        this.pret = 0;
        this.trapa = false;
        this.capacitate = 0;
    }

    int capacitate;

    public int getNumarLocuri() {
        return numarLocuri;
    }

    public String getModel() {
        return model;
    }

    public double getPret() {
        return pret;
    }

    public boolean isTrapa() {
        return trapa;
    }

    public void setTrapa(boolean trapa) {
        this.trapa = trapa;
    }

    public int getCapacitate() {
        return capacitate;
    }

    public void setCapacitate(int capacitate) {
        this.capacitate = capacitate;
    }
    @Override
    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public void setNumarLocuri(int numarLocuri) {
        this.numarLocuri = numarLocuri;
    }

    @Override
    public void setPret(double pret) {
        this.pret = pret;
    }

    @Override
    public void hasTrapa(boolean trapa) {
        this.trapa = trapa;
    }

    @Override
    public String showDetails() {
        String detalii = "Masina cu modelul "+ this.model + " are "+ this.numarLocuri;
        return detalii;
    }
}
