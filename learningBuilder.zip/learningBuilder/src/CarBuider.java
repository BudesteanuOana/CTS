public interface CarBuider {
    public void buildModel();
    public void buildNumarLocuri();
    public void buildPret();
    public void buildTrapa();
    public Car getCar();
}
