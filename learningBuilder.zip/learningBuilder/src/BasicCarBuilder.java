public class BasicCarBuilder implements CarBuider {

    public Car car;

    public BasicCarBuilder() {
        this.car = new BasicCar();
    }
    @Override
    public void buildModel() {
        this.car.setModel("pateu cu paine");
    }

    public void buildCapacitate() {
        ((BasicCar)car).setCapacitate(10);
    }

    @Override
    public void buildNumarLocuri() {
        this.car.setNumarLocuri(2);
    }

    @Override
    public void buildPret() {
        this.car.setPret(10);
    }

    @Override
    public void buildTrapa() {
        this.car.hasTrapa(true);
    }

    @Override
    public Car getCar() {
        return this.car;
    }
}
