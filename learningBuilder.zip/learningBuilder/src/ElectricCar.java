public class ElectricCar implements Car {

    int numarLocuri;
    String model;
    double pret;
    boolean trapa;
    int batteryLevel;

    public ElectricCar(int numarLocuri, String model, double pret, boolean trapa, int batteryLevel) {
        this.numarLocuri = numarLocuri;
        this.model = model;
        this.pret = pret;
        this.trapa = trapa;
        this.batteryLevel = batteryLevel;
    }

    public ElectricCar() {
        this.numarLocuri = 0;
        this.model = "";
        this.pret = 0;
        this.trapa = false;
        this.batteryLevel = 0;
    }
    public int getNumarLocuri() {
        return numarLocuri;
    }

    public String getModel() {
        return model;
    }

    public double getPret() {
        return pret;
    }

    public boolean isTrapa() {
        return trapa;
    }

    public void setTrapa(boolean trapa) {
        this.trapa = trapa;
    }

    public int getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(int batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    @Override
    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public void setNumarLocuri(int numarLocuri) {
        this.numarLocuri = numarLocuri;
    }

    @Override
    public void setPret(double pret) {
        this.pret = pret;
    }

    @Override
    public void hasTrapa(boolean trapa) {
        this.trapa = trapa;
    }

    @Override
    public String showDetails() {
        String detalii = "Masina cu modelul "+ this.model + " are "+ this.numarLocuri;
        return detalii;
    }
}
