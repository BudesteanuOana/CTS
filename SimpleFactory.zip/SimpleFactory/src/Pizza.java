public interface Pizza {
    void prepare();
}
