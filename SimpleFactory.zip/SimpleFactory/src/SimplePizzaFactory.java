public class SimplePizzaFactory {
    public enum pizzaType {
        Pepperoni,
        Cheese,
        Veggie
    }
    public Pizza createPizza(pizzaType request) {
        Pizza pizza = null;
        switch (request) {
            case Cheese:
                pizza = new CheesePizza();
                break;

            case Veggie:
                pizza = new VeggiePizza();
                break;

            case Pepperoni:
                pizza = new PepperoniPizza();
                break;

            default:
                System.out.println("Invalid pizza type! :P");
                break;
        }
        return pizza;
    }
}
