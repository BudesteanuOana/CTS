public class PepperoniPizza implements Pizza{

    public PepperoniPizza(){
        System.out.println("This is a pepperoni pizza!");
    }
    @Override
    public void prepare() {
        System.out.println("Pepperoni pizza prepared!");
    }
}
