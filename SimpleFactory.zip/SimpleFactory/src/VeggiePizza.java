public class VeggiePizza implements Pizza {

    public VeggiePizza() {
        System.out.println("This is a veggie pizza!");
    }
    @Override
    public void prepare() {
        System.out.println("Veggie pizza prepared!");
    }
}
