public class Main {
    public static void main(String[] args) {
        SimplePizzaFactory factory = new SimplePizzaFactory();

        Pizza cheesePizza = factory.createPizza(SimplePizzaFactory.pizzaType.Cheese);
        cheesePizza.prepare();

        Pizza pepperoniPizza = factory.createPizza(SimplePizzaFactory.pizzaType.Pepperoni);
        pepperoniPizza.prepare();

        Pizza veggiePizza = factory.createPizza(SimplePizzaFactory.pizzaType.Veggie);
        veggiePizza.prepare();
    }
}