public class CheesePizza implements Pizza{
    public CheesePizza(){
        System.out.println("This is a cheese pizza!");
    }
    @Override
    public void prepare() {
        System.out.println("Cheese pizza prepared!");
    }
}
