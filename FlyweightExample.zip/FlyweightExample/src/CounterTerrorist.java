public class CounterTerrorist implements Player {

    public final String TASK;
    private String weapon;

    public CounterTerrorist() {
        this.TASK = "defuse the bomb";
    }

    @Override
    public void assignWeapon(String weapon) {
        this.weapon = weapon;
    }

    @Override
    public void mission() {
        System.out.println("The counter terrorist with the weapon " + this.weapon + " has to " + this.TASK);
    }
}
