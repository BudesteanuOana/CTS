public class Main {
    public static void main(String[] args) {
        // create two terrorist and two counter terrorist players
        Player terrorist1 = PlayerFactory.getPlayer("Terrorist");
        Player terrorist2 = PlayerFactory.getPlayer("Terrorist");
        Player counterTerrorist1 = PlayerFactory.getPlayer("CounterTerrorist");
        Player counterTerrorist2 = PlayerFactory.getPlayer("CounterTerrorist");

        // assign weapons to the players
        terrorist1.assignWeapon("AK-47");
        terrorist2.assignWeapon("Maverick");
        counterTerrorist1.assignWeapon("Gut Knife");
        counterTerrorist2.assignWeapon("Desert Eagle");

        // send the players on their missions
        terrorist1.mission();
        terrorist2.mission();
        counterTerrorist1.mission();
        counterTerrorist2.mission();
    }
}