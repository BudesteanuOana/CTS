public class DealerAuto {
    private MasinaFamilie masinaFamilie;
    private  MasinaElectrica masinaElectrica;
    private  MasinaSport masinaSport;

    public DealerAuto() {
        this.masinaFamilie = new MasinaFamilie("Masina familie cu 8 locuri");
        this.masinaElectrica = new MasinaElectrica("Masina electrica Tesla");
        this.masinaSport = new MasinaSport("Masina sport");
    }

    public String descriereMasinaSport() {
        return masinaSport.getDescriere();
    }
    public String descriereMasinaFamilie() {
        return masinaFamilie.getDescriere();
    }
    public String descriereMasinaElectrica() {
        return masinaElectrica.getDescriere();
    }
}
