public class MasinaSport implements Automobil {

    String descriere;

    public MasinaSport(String descriere) {
        this.descriere = descriere;
    }

    public String getDescriere() {
        return descriere;
    }

}
