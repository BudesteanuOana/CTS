public interface Automobil {
    String descriere = null;
}
