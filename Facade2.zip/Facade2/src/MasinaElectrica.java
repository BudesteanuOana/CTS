public class MasinaElectrica implements Automobil {

    String descriere;

    public MasinaElectrica(String descriere) {
        this.descriere = descriere;
    }

    public String getDescriere() {
        return descriere;
    }

}
