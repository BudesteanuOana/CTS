public class Main {
    public static void main(String[] args) {
        DealerAuto dealerAuto = new DealerAuto();
        System.out.println(dealerAuto.descriereMasinaSport());
        System.out.println(dealerAuto.descriereMasinaFamilie());
        System.out.println(dealerAuto.descriereMasinaElectrica());
    }
}