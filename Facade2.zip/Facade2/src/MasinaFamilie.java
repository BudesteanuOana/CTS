public class MasinaFamilie implements Automobil {

    String descriere;

    public MasinaFamilie(String descriere) {
        this.descriere = descriere;
    }

    public String getDescriere() {
        return descriere;
    }

}
