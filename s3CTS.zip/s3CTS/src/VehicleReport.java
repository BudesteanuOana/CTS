public class VehicleReport extends Vehicle {
    public void printDetails() {
        System.out.println("Details of the vehicle: \n " + "Value: "+ this.getValue());
    }
}
