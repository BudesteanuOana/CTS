public class VehicleDatabase {
    public void addVehicleToDB() {
        System.out.println("Vehicle added to the DB");
    }
}
