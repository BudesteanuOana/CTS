package ro.ase.cts.s02;

import java.io.*;

public class MatrixDataHandler {
    private int[][] matrix;
    private int height;
    private int width;
    private String filename;

    public MatrixDataHandler(int height, int width, String filename) {
        initializeMatrix( height,  width,  filename);
        writeMatrixInFile();
    }
    private void initializeMatrix(int width, int height, String filename){
        this.height = height;
        this.width = width;
        this.filename = filename;
        this.matrix = new int[height][];

        for (int i = 0; i < height; i++) {
            this.matrix[i] = new int[width];
        }
    }

    private void writeMatrixInFile(){
        try {
            FileWriter writer = new FileWriter(this.filename);
            writer.write(this.height + " " + this.width + "\n");
            for (int i = 0; i < this.height; i++) {
                for (int j = 0; j < this.width; j++) {
                    writer.write(this.matrix[i][j] + " ");
                }
                writer.write("\n");
            }
            writer.close();
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
        }
    }

    private void readMatrixFromFile(){
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line = reader.readLine();
            height = Integer.parseInt(line.split(" ")[0]);
            width = Integer.parseInt(line.split(" ")[1]);
            for (int i = 0; i < this.height; i++) {
                line = reader.readLine();
                for (int j = 0; j < this.width; j++) {
                    this.matrix[i][j] = Integer.parseInt(line.split(" ")[j]);
                }
            }
            reader.close();
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
        }

    }

    private void checkIndex(int posH, int posW){
        if(this.width<posW || this.height<posH){
            initializeMatrix(posH, posW, this.filename);
        }
    }

    /**
     *
     * @param filename - fisierul din care citim
     * @param posH -  pozitia pe linie
     * @param posW -  pozitia pe coloana
     * @param value
     */
    public void modifyValueAndUpdateFile(String filename, int posH, int posW, int value) {
        readMatrixFromFile();
        checkIndex(posH, posW);
        matrix[posH-1][posW-1] = value;
        writeMatrixInFile();
    }

    /**
     *
     * @param filename - fisierul din care citim
     * @param posH -  pozitia pe linie
     * @param posW -  pozitia pe coloana
     */
    public int getValueFromPosition(String filename, int posH, int posW) {

        readMatrixFromFile();

        checkIndex(posW, posH);

        return this.matrix[posH-1][posW-1];

    }
}
