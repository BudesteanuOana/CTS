public interface Flyweight {
    void operation();
}
