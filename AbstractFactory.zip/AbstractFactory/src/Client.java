public class Client {
    public static void main(String[] args) {
        AbstractFactory darkThemeFactory = new DarkThemeFactory();
        Button darkButton = darkThemeFactory.createButton();
        TextField darkTextField = darkThemeFactory.createTextField();

        darkButton.render();
        darkTextField.render();


        AbstractFactory lightThemeFactory = new LightThemeFactory();
        Button lightButton = lightThemeFactory.createButton();
        TextField lightTextField = lightThemeFactory.createTextField();
        
        lightButton.render();
        lightTextField.render();
    }
}