public interface AbstractFactory {
    Button createButton();
    TextField createTextField();
}
