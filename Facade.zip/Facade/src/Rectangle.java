public class Rectangle {
    public void draw() {
        System.out.println("Dreptunghiul s a desenat");
    }
}
