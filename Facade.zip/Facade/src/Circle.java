public class Circle {
    public void draw() {
        System.out.println("Cercul s a desenat");
    }
}
