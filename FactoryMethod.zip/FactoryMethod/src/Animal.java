public interface Animal {
    void makeSound();
}
