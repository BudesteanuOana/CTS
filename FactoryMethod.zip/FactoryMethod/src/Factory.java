public abstract class Factory {
    public abstract Animal createAnimal();
}
