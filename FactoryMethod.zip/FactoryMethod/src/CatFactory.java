public class CatFactory extends Factory {
    @Override
    public Animal createAnimal() {
        return new Cat();
    }
}
