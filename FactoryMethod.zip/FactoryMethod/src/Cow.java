public class Cow implements Animal {

    public Cow() {
        System.out.println("Cow created!");
    }
    @Override
    public void makeSound() {
        System.out.println("Moo Moo");
    }
}
