public class Main {
    public static void main(String[] args) {
        Factory dogFactory = new DogFactory();
        Animal dog = dogFactory.createAnimal();
        dog.makeSound();

        Factory catFactory = new CatFactory();
        Animal cat = catFactory.createAnimal();
        cat.makeSound();

        Factory cowFactory = new CowFactory();
        Animal cow = cowFactory.createAnimal();
        cow.makeSound();
    }
}