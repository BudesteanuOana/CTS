public class Cat implements Animal {

    public Cat(){
        System.out.println("Cat created!");
    }
    @Override
    public void makeSound() {
        System.out.println("Meow Meow");
    }
}
