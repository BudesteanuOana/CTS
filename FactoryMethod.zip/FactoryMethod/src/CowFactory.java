public class CowFactory extends Factory {
    @Override
    public Animal createAnimal() {
        return new Cow();
    }
}
