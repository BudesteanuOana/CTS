public class Main {


    public static void main(String[] args) {

//        ChatServer chatServer1 = ChatServer.getInstance();
//        System.out.println(chatServer1.showStatus());

        ChatServer chatServer2 = ChatServer.getInstance(8081, "Grupa 1081");
        //System.out.println(chatServer.toString());
        System.out.println(chatServer2.showStatus());

        ChatServer chatServer3 = ChatServer.getInstance(8082, "Grupa 1082");
        System.out.println(chatServer3.showStatus());

        new Thread(()->{
            CatServer carServer = CatServer.getInstance();
            carServer.setNoCats(2);
            System.out.println(carServer.showStatus());
        }).start();

        new Thread(()->{
            CatServer carServer2 = CatServer.getInstance();
            carServer2.setNoCats(3);
            System.out.println(carServer2.showStatus());
        }).start();

        new Thread(()->{
            CatServer carServer2 = CatServer.getInstance();
            carServer2.setNoCats(4);
            System.out.println(carServer2.showStatus());
        }).start();

        EnumSingleton enumSingleton1 = EnumSingleton.INSTANCE;
        EnumSingleton enumSingleton2 = EnumSingleton.INSTANCE;
        enumSingleton1.setValue("Does this work??");
        System.out.println(enumSingleton1.getValue());
        enumSingleton2.setValue("Hello again!");
        System.out.println(enumSingleton2.getValue());
        System.out.println(enumSingleton1.getValue());
    }
}