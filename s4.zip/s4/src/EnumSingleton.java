// Enum sigleton example
// Enums are inherently serializable.
// No problems of reflection occur.
// It is thread-safe to create enum instances.
public enum EnumSingleton {
    INSTANCE;

    String value;

    public String  getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
