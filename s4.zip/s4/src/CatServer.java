// Thread safe singleton example
public class CatServer {

    String serverName;
    int adoptionCenterCode;
    int catsNo;

    private CatServer() {
        this.serverName = "Cat Server";
        this.adoptionCenterCode = 4444;
        this.catsNo = 0;
    }

    public int getNoCats() {
        return catsNo;
    }

    public void setNoCats(int noCats) {
        this.catsNo = noCats;
    }

    private static CatServer instance;

    public static synchronized CatServer getInstance() {
        if(instance == null){
            instance=new CatServer();
        }
        return instance;
    }

    public String showStatus() {
        return serverName+" from location having the code: "+adoptionCenterCode+" has "+catsNo+" cats available at this moment ";
    }
}
